</div><!--end .row -->

</div><!--end .col-md-11 -->


</div><!--end .col-lg-offset-0 col-md-12 -->


</div> <!--end .section-body -->

</section>
</div><!--end #content-->

<!-- END CONTENT -->

<?php include('navigation.php'); ?>
</div><!--end #base-->

<!-- END BASE -->

<!-- BEGIN JAVASCRIPT -->

<script src="<?= base_url(); ?>assets/js/libs/jquery/jquery-1.11.2.min.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/jquery/jquery-migrate-1.2.1.min.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/bootstrap/bootstrap.min.js"></script>

<script src="<?= base_url(); ?>assets/js/libs/spin.js/spin.min.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/autosize/jquery.autosize.min.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>

<script src="<?= base_url(); ?>assets/js/libs/ckeditor/ckeditor.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/ckeditor/adapters/jquery.js"></script>

<script src="<?= base_url(); ?>assets/js/libs/inputmask/jquery.inputmask.bundle.min.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/moment/moment.min.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/bootstrap-datepicker/bootstrap-datepicker.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/wizard/jquery.bootstrap.wizard.min.js"></script>

<script src="<?= base_url(); ?>assets/js/core/source/AppNavigation.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/flot/jquery.flot.min.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/flot/jquery.flot.time.min.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/flot/jquery.flot.resize.min.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/flot/jquery.flot.orderBars.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/flot/jquery.flot.pie.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/flot/curvedLines.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/jquery-knob/jquery.knob.min.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/sparkline/jquery.sparkline.min.js"></script>


<script src="<?= base_url(); ?>assets/js/libs/nanoscroller/jquery.nanoscroller.min.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/toastr/toastr.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/raphael/raphael-min.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/morris.js/morris.min.js"></script>

<script src="<?= base_url(); ?>assets/js/libs/jquery-validation/dist/jquery.validate.min.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/jquery-validation/dist/additional-methods.min.js"></script>
<script src="<?= base_url(); ?>assets/js/core/demo/DemoFormWizard.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/d3/d3.min.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/d3/d3.v3.js"></script>
<script src="<?= base_url(); ?>assets/js/libs/rickshaw/rickshaw.min.js"></script>


<script src="<?= base_url(); ?>assets/js/core/source/App.js"></script>
<script src="<?= base_url(); ?>assets/js/core/source/AppOffcanvas.js"></script>
<script src="<?= base_url(); ?>assets/js/core/source/AppCard.js"></script>
<script src="<?= base_url(); ?>assets/js/core/source/AppForm.js"></script>
<script src="<?= base_url(); ?>assets/js/core/source/AppNavSearch.js"></script>
<script src="<?= base_url(); ?>assets/js/core/source/AppVendor.js"></script>
<script src="<?= base_url(); ?>assets/js/core/demo/Demo.js"></script>
<script src="<?= base_url(); ?>assets/js/core/demo/DemoFormEditors.js"></script>
<script src="<?= base_url(); ?>assets/js/core/demo/DemoFormComponents.js"></script>
<script src="<?= base_url(); ?>assets/js/core/demo/DemoCharts.js"></script>

<script src="<?= base_url(); ?>assets/js/core/demo/DemoDashboard.js"></script>

<script src="<?= base_url(); ?>assets/js/custom/master_ajax.js"></script>

<script src="<?= base_url(); ?>assets/js/libs/select2/select2.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/TableDnD/0.9.1/jquery.tablednd.js" integrity="sha256-d3rtug+Hg1GZPB7Y/yTcRixO/wlI78+2m08tosoRn7A=" crossorigin="anonymous"></script>



<script>


$(document).ajaxComplete(function () {
    $('[data-toggle="tooltip"]').tooltip();
});


</script>



<!-- END JAVASCRIPT -->




